﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EloRoteamento
{
    static class Program
    {
        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Map(args));
                // Application.Run(new Map(new string[] { "vendedor=Paulo", "datai=29/09/2019 10:40:19", "dataf=29/09/2019 12:17:15", "locais=-23.981,-53.8901;-23.995,-53.8921;-24.010,-53.8981;-23.105,-53.9020;-23.155,-53.9070;-23.195,-53.9112;-23.205,-53.9122;-23.225,-53.9132;-23.235,-53.9142;-23.245,-53.9162;-23.275,-53.9182;-23.295,-53.9302;-23.395,-53.9402;-23.495,-53.9502;-24.095,-54.1502;" }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
