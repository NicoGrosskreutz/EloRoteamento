﻿using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace EloRoteamento
{
    public partial class Map : Form
    {
        /// <summary>
        ///  Lista aux para a tela
        /// </summary>
        private List<PointLatLng> Points { get; set; } = null;

        public Map()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;
            this.WindowState = FormWindowState.Maximized;

            this.txVendedor.ReadOnly = true;
            this.txDataInicial.ReadOnly = true;
            this.txDataFinal.ReadOnly = true;

            this.txVendedor.BackColor = Color.White;
            this.txDataInicial.BackColor = Color.White;
            this.txDataFinal.BackColor = Color.White;
            this.txLocais.BackColor = Color.White;
        }

        public Map(string[] args)
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterParent;
            this.WindowState = FormWindowState.Maximized;

            this.txVendedor.ReadOnly = true;
            this.txDataInicial.ReadOnly = true;
            this.txDataFinal.ReadOnly = true;

            this.txVendedor.BackColor = Color.White;
            this.txDataInicial.BackColor = Color.White;
            this.txDataFinal.BackColor = Color.White;
            this.txLocais.BackColor = Color.White;

            gMap.MapProvider = GoogleMapProvider.Instance;
            GMaps.Instance.Mode = AccessMode.ServerAndCache;
            gMap.Position = new PointLatLng(-14.2350, -51.9253);
            gMap.Zoom = 5;

            LoadLocalization(args);
        }

        private bool LoadLocalization(string[] args)
        {
            try
            {
                if (args.Length > 0)
                {
                    var points = new List<PointLatLng>();

                    args.ToList().ForEach((aux) => 
                    {
                        if (aux.ToLower().StartsWith("vendedor="))
                            txVendedor.Text = aux.Replace("vendedor=", "");

                        if (aux.ToLower().StartsWith("datai="))
                            txDataInicial.Text = aux.Replace("datai=", "");

                        if (aux.ToLower().StartsWith("dataf="))
                            txDataFinal.Text = aux.Replace("dataf=", "");

                        if (aux.ToLower().StartsWith("locais="))
                        {
                            string[] positions = aux.Replace("locais=", "").Replace(" ", "").Split(';');

                            positions.ToList().ForEach((position) => 
                            {
                                try
                                {
                                    string[] values = position.Split(',');
                                    points.Add(new PointLatLng(TryParseDouble(values[0]), TryParseDouble(values[1])));
                                }
                                catch
                                {
                                    Console.WriteLine("Valor de posição inválida!");
                                }
                            });

                            this.Points = points;
                        }
                    });

                    if (this.Points != null)
                        if (this.Points.Count > 0)
                        {
                            GMapRoute route = new GMapRoute(this.Points, "routes");
                            GMapOverlay overlay = new GMapOverlay("routesOverlay");
                            overlay.Routes.Add(route);
                            gMap.Overlays.Add(overlay);
                            gMap.Zoom = 10;
                        }
                }
                else
                    throw new Exception("Nenhum parâmetro informado para o aplicativo!");

                return true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        private double TryParseDouble(string value)
        {
            return double.TryParse(value.Replace(".", ","), out double aux) ? aux : 0;
        }

        private void Map_Load(object sender, EventArgs e)
        {
            if (this.Points.Count > 0)
                Points.ToList().ForEach((aux) => 
                {
                    txLocais.Text += $"{aux.Lat} | {aux.Lng}" + "\n";
                });
        }
    }
}
