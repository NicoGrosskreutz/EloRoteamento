﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EloRoteamento
{
    static class Program
    {
        /// <summary>
        /// Ponto de entrada principal para o aplicativo.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                // Application.Run(new Map(args));
                Application.Run(new Map(new string[] { "vendedor=Paulo", "datai=29/09/2019 10:40:19", "dataf=29/09/2019 12:17:15", "locais=-23.981,-53.8901;-23.995,-53.8921" }));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
